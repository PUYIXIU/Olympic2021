package olympic.game.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DBUtil{
	public static final String UNAME="root";
	public static final String UPWD="123456";
	public static final String URL="jdbc:mysql://127.0.0.1:3306/olympic2021?useUnicode=true&characterEncoding=utf-8";
	public static Connection conn=null;
	public static PreparedStatement pstmt=null;
	public static ResultSet rs=null;
	public static Connection connection() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection(URL,UNAME,UPWD);
	}
	public static PreparedStatement getPreparedStatement(String sql,Object[]params) throws Exception{
		pstmt=connection().prepareStatement(sql);
		if(params!=null) {
			for(int i=0;i<params.length;i++) {
				pstmt.setObject(i+1,params[i]);
			}
		}
		return pstmt;
	}
	public static void ClossAll() throws Exception{
		if(rs!=null) {
			rs.close();
		}
		if(pstmt!=null) {
			pstmt.close();
		}
		if(conn!=null) {
			conn.close();
		}
	}
	public static ResultSet isExist(String sql,Object[]params) throws Exception{
		return getPreparedStatement(sql, params).executeQuery();
	}
	public static void addUser(String sql,Object[]params)throws Exception{
		getPreparedStatement(sql,params).execute();
	}
	
	public static int QueryGameCount(String sql,Object[]params)throws Exception{
		rs=getPreparedStatement(sql, params).executeQuery();
		int count=0;
		while(rs.next()) {
			count=count+1;
		}
		ClossAll();
		return count;
	}
	public static ResultSet QueryGameByPage(String sql,Object[]params) throws Exception{
		return getPreparedStatement(sql,params).executeQuery();
	}
}