package olympic.game.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import olympic.game.dao.UserDao;
import olympic.game.entity.*;

public class UserService{
	UserDao ud=new UserDao();
	public boolean isExist(String username,String password)throws Exception{
		return ud.isExist(username,password);
	}
	public boolean hasExist(String username)throws Exception{
		return ud.hasExist(username);
	}
	public void addUser(String username,String password)throws Exception{
		ud.addUser(username, password);
	}
	public List<Game> showUserGame(String username)throws Exception{
		return ud.showUserGame(username);
	}
	public List<Game> showGame(String date)throws Exception{
		return ud.showGame(date);
	}
	public void userAddGame(int id,String username)throws Exception{
		ud.userAddGame(id,username);
	}
	public void userDelGame(int id,String username)throws Exception{
		ud.userDelGame(id, username);
	}
	public int QueryGameCount(String date,String type,String group,String contry)throws Exception{
		return ud.QueryGameCount(date,type,group,contry);
	}
	public List<Game> QueryGameByPage(String date,String type,String group,String contry,GamePage gpage)throws Exception{
		return ud.QueryGameByPage(date,type,group,contry,gpage);
	}
	public List<Game>RankGame()throws Exception{
		return ud.rankGame();
	}
}