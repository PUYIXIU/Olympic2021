package olympic.game.entity;

import java.sql.Date;

public class Game {
	private int id;
	private String date;
	private String time;
	private String type;
	private String group;
	private String detail;
	private int count;
	private int rank;
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public Game() {}
	public Game(int id) {
		this.id=id;
	}
	public Game(int id,String date,String time,String type,String group,String detail) {
		this.id=id;
		this.date=date;
		this.time=time;
		this.type=type;
		this.group=group;
		this.detail=detail;
	}

	public Game(int id,String date,String time,String type,String group,String detail,int count,int rank) {
		this.id=id;
		this.date=date;
		this.time=time;
		this.type=type;
		this.group=group;
		this.detail=detail;
		this.count=count;
		this.rank=rank;
	}
	public Game(int id,int count,int rank) {
		this.id=id;
		this.count=count;
		this.rank=rank;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	
}
