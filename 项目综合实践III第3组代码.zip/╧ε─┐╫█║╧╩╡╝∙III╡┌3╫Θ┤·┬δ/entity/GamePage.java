package olympic.game.entity;

import java.util.List;

public class GamePage {
	private int pageSize;
	private int currentPage;
	private int numCount;
	private int pageCount;
	private List<Game> Games;
	public GamePage() {}
	public GamePage(int pageSize, int currentPage, int numCount, int pageCount, List<Game> Games) {
		this.pageSize = pageSize;
		this.currentPage = currentPage;
		this.numCount = numCount;
		this.pageCount = pageCount;
		this.Games = Games;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getNumCount() {
		return numCount;
	}
	public void setNumCount(int numCount) {
		this.numCount = numCount;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount() {
		int n=this.numCount%this.pageSize;
		this.pageCount=n==0?this.numCount/this.pageSize:this.numCount/this.pageSize+1;
	}
	public List<Game> getGames() {
		return Games;
	}
	public void setGames(List<Game> Games) {
		this.Games = Games;
	}
	
}
