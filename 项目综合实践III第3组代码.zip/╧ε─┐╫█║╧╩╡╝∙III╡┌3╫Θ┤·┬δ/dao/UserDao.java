package olympic.game.dao;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import olympic.game.util.DBUtil;
import olympic.game.entity.*;

public class UserDao{
	DBUtil db;
	public boolean isExist(String username,String password)throws Exception{
		String sql="SELECT * FROM user WHERE `username`=? AND `password`=?";
		Object []params= {username,password};
		boolean flag=false;
		db.rs=db.isExist(sql,params);
		if(db.rs.next()){
			flag=true;
		}
		db.ClossAll();
		return flag;
	}
	
	public boolean hasExist(String username)throws Exception{
		String sql="SELECT * FROM user WHERE `username`=?";
		Object[]params= {username};
		boolean flag=false;
		db.rs=db.isExist(sql,params);
		if(db.rs.next()) {
			flag=true;
		}
		db.ClossAll();
		return flag;
	}
	public void addUser(String username,String password)throws Exception{
		String sql="INSERT INTO user(`username`,`password`) VALUES(?,?)";
		Object[]params= {username,password};
		db.addUser(sql,params);
		db.ClossAll();
	}

	public void userAddGame(int id,String username)throws Exception{
		String sql="INSERT INTO user_game(`username`,`gameid`) VALUES(?,?)";
		Object[]params= {username,id};
		db.addUser(sql,params);
		db.ClossAll();
	}

	public void userDelGame(int id,String username)throws Exception{
		String sql="DELETE FROM user_game WHERE `username`=? AND `gameid`=?";
		Object[]params= {username,id};
		db.addUser(sql,params);
		db.ClossAll();
	}
	public List<Game> showUserGame(String username)throws Exception{
		String sql="SELECT `gameid` FROM user_game WHERE `username`=?ORDER BY `gameid`" ;
		Object params[]= {username};
		List<Game> games=new ArrayList<>();
		db.rs=db.isExist(sql,params);
		while(db.rs.next()) {
			int id=db.rs.getInt("gameid");
			Game game=new Game(id);
			games.add(game);
		}
		db.ClossAll();
		for(Game game:games) {
			sql="SELECT * FROM time WHERE `id`=?";
			int id=game.getId();
			Object param[]= {id};
			db.rs=db.isExist(sql,param);
			if(db.rs.next()) {
				String date=db.rs.getString("date");
				game.setDate(date);
				String time=db.rs.getString("time");
				game.setTime(time);
				String type=db.rs.getString("type");
				game.setType(type);
				String group=db.rs.getString("group");
				game.setGroup(group);
				String detail=db.rs.getString("detail");
				game.setDetail(detail);
			}
			db.ClossAll();
		}
		return games;
	}
	public List<Game> showGame(String date)throws Exception{
		String sql="SELECT * FROM time WHERE `date`=?";
		Object params[]= {date};
		List<Game> games=new ArrayList<>();
		db.rs=db.isExist(sql,params);
		while(db.rs.next()) {
			int id=db.rs.getInt("id");
			String day=db.rs.getString("date");
			String time=db.rs.getString("time");
			String type=db.rs.getString("type");
			String group=db.rs.getString("group");
			String detail=db.rs.getString("detail");
			Game game=new Game(id,day,time,type,group,detail);
			games.add(game);
		}
		return games;
	}
	
	public List<Game> rankGame()throws Exception{
		String sql="SELECT * FROM time";
		Object params[]= {};
		List<Game>games=new ArrayList<>();
		List<Game>top_games=new ArrayList<>();
		List<Game>topGames=new ArrayList<>();
		int count=db.QueryGameCount(sql,params);
		for(int i=1;i<=count;i++) {
			Game game=new Game(i);
			game.setCount(0);
			games.add(game);
		}
		
		sql="SELECT * FROM user_game";
		db.rs=db.isExist(sql,null);
		while(db.rs.next()) {
			int id=db.rs.getInt("gameid");
			for(Game game:games) {
				if(id==game.getId()) {
					game.setCount(game.getCount()+1);
				}
			}
		}
		for(int i=1;i<=9;i++) {
			int top=1;
			int top_count=0;
			for(Game game:games) {
				if(game.getCount()>=top_count) {
					top_count=game.getCount();
					top=game.getId();
				}
			}
			for(Game game:games) {
				if(game.getId()==top) {
					int id=game.getId();
					int z_count=game.getCount();
					Game top_game=new Game(id,z_count,i);
					Game replace_game=new Game(id,0,0);
					top_games.add(top_game);
					games.set(top-1,replace_game);
				}
			}
		}
			for(Game game:top_games) {
				int id=game.getId();
				sql="SELECT * FROM time WHERE `id`=?";
				Object param[]= {id};
				db.rs=db.isExist(sql,param);
				if(db.rs.next()) {
					Game newgame=new Game(game.getId(),game.getCount(),game.getRank());
					String day=db.rs.getString("date");
					newgame.setDate(day);
					String time=db.rs.getString("time");
					newgame.setTime(time);
					String type=db.rs.getString("type");
					newgame.setType(type);
					String group=db.rs.getString("group");
					newgame.setGroup(group);
					String detail=db.rs.getString("detail");
					newgame.setDetail(detail);
					topGames.add(newgame);
				}
			}
		return topGames;
	}
	public int QueryGameCount(String date,String type,String group_type,String contry)throws Exception{

		if((date.equals("全部"))&&(type.equals("全部"))&&(group_type.equals("全部"))&&(contry.equals("全部"))) {

			String sql="SELECT * FROM time";
			Object params[]= {};
			return db.QueryGameCount(sql,params);
		}
		else if((!date.equals("全部"))&&(type.equals("全部"))&&(group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=?";
			Object params[]= {date};
			return db.QueryGameCount(sql,params);
		}
		else if((date.equals("全部"))&&(!type.equals("全部"))&&(group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `type`=?";
			Object params[]= {type};
			return db.QueryGameCount(sql,params);
		}
		else if((date.equals("全部"))&&(type.equals("全部"))&&(!group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `group_type`=?";
			Object params[]= {group_type};
			return db.QueryGameCount(sql,params);
		}
		else if((date.equals("全部"))&&(type.equals("全部"))&&(group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `contry`=?";
			Object params[]= {contry};
			return db.QueryGameCount(sql,params);
		}
		else if((!date.equals("全部"))&&(!type.equals("全部"))&&(group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `type`=?";
			Object params[]= {date,type};
			return db.QueryGameCount(sql,params);
		}
		else if((!date.equals("全部"))&&(type.equals("全部"))&&(!group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `group_type`=?";
			Object params[]= {date,group_type};
			return db.QueryGameCount(sql,params);
		}
		else if((!date.equals("全部"))&&(type.equals("全部"))&&(group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `contry`=?";
			Object params[]= {date,contry};
			return db.QueryGameCount(sql,params);
		}
		else if((date.equals("全部"))&&(!type.equals("全部"))&&(!group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `type`=? AND `group_type`=?";
			Object params[]= {type,group_type};
			return db.QueryGameCount(sql,params);
		}
		else if((date.equals("全部"))&&(!type.equals("全部"))&&(group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `type`=? AND `contry`=?";
			Object params[]= {type,contry};
			return db.QueryGameCount(sql,params);
		}
		else if((date.equals("全部"))&&(type.equals("全部"))&&(!group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `group_type`=? AND `contry`=?";
			Object params[]= {group_type,contry};
			return db.QueryGameCount(sql,params);
		}
		else if((!date.equals("全部"))&&(!type.equals("全部"))&&(!group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `type`=? AND `group_type`=?";
			Object params[]= {date,type,group_type};
			return db.QueryGameCount(sql,params);
		}
		else if((!date.equals("全部"))&&(!type.equals("全部"))&&(group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `type`=? AND `contry`=?";
			Object params[]= {date,type,contry};
			return db.QueryGameCount(sql,params);
		}
		else if((!date.equals("全部"))&&(type.equals("全部"))&&(!group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `group_type`=? AND `contry`=?";
			Object params[]= {date,group_type,contry};
			return db.QueryGameCount(sql,params);
		}
		else if((date.equals("全部"))&&(!type.equals("全部"))&&(!group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `type`=? AND `group_type`=? AND `contry`=?";
			Object params[]= {type,group_type,contry};
			return db.QueryGameCount(sql,params);
		}
		else {			
			String sql="SELECT * FROM time WHERE `date`=? AND `type`=? AND `group_type`=? AND `contry`=?";
			Object params[]= {date,type,group_type,contry};
			return db.QueryGameCount(sql,params);
		}
	}
	public List<Game> QueryGameByPage(String date,String type,String group_type,String contry,GamePage gpage)throws Exception{
		List<Game> games=new ArrayList<>();
		System.out.print(date+" "+type+" "+group_type+" "+contry);
		if((date.equals("全部"))&&(type.equals("全部"))&&(group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time LIMIT ?,?";
			Object params[]= {gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((!date.equals("全部"))&&(type.equals("全部"))&&(group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? LIMIT ?,?";
			Object params[]= {date,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((date.equals("全部"))&&(!type.equals("全部"))&&(group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `type`=? LIMIT ?,?";
			Object params[]= {type,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((date.equals("全部"))&&(type.equals("全部"))&&(!group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `group_type`=? LIMIT ?,?";
			Object params[]= {group_type,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((date.equals("全部"))&&(type.equals("全部"))&&(group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `contry`=? LIMIT ?,?";
			Object params[]= {contry,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((!date.equals("全部"))&&(!type.equals("全部"))&&(group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `type`=? LIMIT ?,?";
			Object params[]= {date,type,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((!date.equals("全部"))&&(type.equals("全部"))&&(!group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `group_type`=? LIMIT ?,?";
			Object params[]= {date,group_type,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((!date.equals("全部"))&&(type.equals("全部"))&&(group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `contry`=? LIMIT ?,?";
			Object params[]= {date,contry,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((date.equals("全部"))&&(!type.equals("全部"))&&(!group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `type`=? AND `group_type`=? LIMIT ?,?";
			Object params[]= {type,group_type,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((date.equals("全部"))&&(!type.equals("全部"))&&(group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `type`=? AND `contry`=? LIMIT ?,?";
			Object params[]= {type,contry,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((date.equals("全部"))&&(type.equals("全部"))&&(!group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `group_type`=? AND `contry`=? LIMIT ?,?";
			Object params[]= {group_type,contry,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((!date.equals("全部"))&&(!type.equals("全部"))&&(!group_type.equals("全部"))&&(contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `type`=? AND `group_type`=? LIMIT ?,?";
			Object params[]= {date,type,group_type,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((!date.equals("全部"))&&(!type.equals("全部"))&&(group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `type`=? AND `contry`=? LIMIT ?,?";
			Object params[]= {date,type,contry,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((!date.equals("全部"))&&(type.equals("全部"))&&(!group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `date`=? AND `group_type`=? AND `contry`=? LIMIT ?,?";
			Object params[]= {date,group_type,contry,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else if((date.equals("全部"))&&(!type.equals("全部"))&&(!group_type.equals("全部"))&&(!contry.equals("全部"))) {
			String sql="SELECT * FROM time WHERE `type`=? AND `group_type`=? AND `contry`=? LIMIT ?,?";
			Object params[]= {type,group_type,contry,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
			db.rs=db.QueryGameByPage(sql, params);
		}
		else {			
			String sql="SELECT * FROM time WHERE `date`=? AND `type`=? AND `group_type`=? AND `contry`=? LIMIT ?,?";
			Object params[]= {date,type,group_type,contry,gpage.getCurrentPage()*gpage.getPageSize(),gpage.getPageSize()};
		}
		while(db.rs.next()) {
			int id=db.rs.getInt("id");
			String day=db.rs.getString("date");
			String time=db.rs.getString("time");
			String gtype=db.rs.getString("type");
			String group=db.rs.getString("group");
			String detail=db.rs.getString("detail");
			Game game=new Game(id,day,time,gtype,group,detail);
			games.add(game);
		}
		db.ClossAll();
		return games;
	}
	
}